/* Window Load functions */

$(window).load(function(){
    setTimeout(function(){

    });
});


$(document).ready(function(){

});

$(window).resize(function(){

});

